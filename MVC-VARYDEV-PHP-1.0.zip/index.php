<?php 


//Incluindo a class mãe

require_once "lib/System.php";

$System = new System();

$System->Run("Tetse");

 ?>