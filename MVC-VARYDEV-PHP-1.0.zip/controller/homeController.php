<?php 


class homeController{


	public function index(){
		echo "Certo!";
	}

	public function teste(){
		echo "Certo 2 !";
	}

}


 ?>