<?php 


class Model{

	public $con;


	public function __construct(){
		$this->connect();
	}


	public function connect(){
		try {
    		$conn = new PDO("mysql:host=localhost;dbname=test;charset=utf8mb4", "root", "");
    		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    		echo "d";
    	} catch(PDOException $e) {
    		echo "Erro ao conectar com o banco de dados!: " . $e->getMessage();
    	}
	}

}

$model = new Model();
