<?php 



class System{

	private $url;
	private $exploder;
	private $area;
	private $controller;
	private $action;
	private $params;
	private $nome;


	protected $routers = array(
			'site'=>'site',
			'admin'=>'admin'
	);

	protected $routerOnRaiz = 'site';

	protected $onRaiz = false;


	public function Run($nome){
		$this->nome = $nome;
		$this->setUrl();
		$this->setExploder();
		$this->setController();
		$this->setAction();
	}

	private function setUrl(){
		$this->url = empty($_GET['url']) ? 'home/index' : $_GET['url'];
	}

	private function setExploder(){
		$this->exploder = explode('/', $this->url);
		//var_dump($this->exploder);
	}

	private function setController(){
		$this->controller = empty($this->exploder[0]) ? 'home' : $this->exploder[0];
		$file = "controller/".$this->controller."Controller.php";
		if (file_exists($file)){
			include_once $file;
		}else{
			include "views/content/shared/404.phtml";
		}
		//echo $this->controller;
	}

	private function setAction(){
		$this->action = empty($this->exploder[1]) ? 'index' : $this->exploder[1];
		$object = $this->controller."Controller";
		if (method_exists($object, $this->action)) {
			$c = new $object();
			 $act = $this->action;
			$c->$act();
		}elseif(empty($this->exploder[0])){
			include "views/content/shared/404.phtml";
		}else{
			include "views/content/shared/404.phtml";
		}
		//echo " ".$this->action;
	}


}